﻿using System.ComponentModel.DataAnnotations;

namespace AppSITBODEGA.Models
{
    public class EquipoModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El código es requerido")]
        public string Codigo { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "La categoría es requerida")]
        public string Categoria { get; set; }

        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Serie { get; set; }

        [Required(ErrorMessage = "El estado es requerido")]
        public string Estado { get; set; }

        public string Ubicacion { get; set; }
        public string Usuario { get; set; }
        public string Notas { get; set; }
    }
}