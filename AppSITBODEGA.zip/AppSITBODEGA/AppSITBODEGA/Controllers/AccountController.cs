﻿using Microsoft.AspNetCore.Mvc;
using AppSITBODEGA.Models;

namespace AppSITBODEGA.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Aquí irá tu lógica de autenticación
                // Por ahora, usaremos credenciales de ejemplo
                if (model.Email == "admin@iberostar.com" && model.Password == "123456789")
                {
                    return RedirectToAction("Dashboard", "Home");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Usuario o contraseña incorrectos");
                }
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ForgotPassword(string email)
        {
            // Lógica para recuperar contraseña
            TempData["Message"] = "Se ha enviado un correo para restablecer tu contraseña";
            return RedirectToAction("Login");
        }
    }
}