using Microsoft.AspNetCore.Mvc;
using AppSITBODEGA.Models;
using System.Diagnostics;
using System.Collections.Generic;

namespace AppSITBODEGA.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return RedirectToAction("Dashboard");
        }

        public IActionResult Dashboard()
        {
            ViewBag.TotalEquipos = 219;
            ViewBag.Disponibles = 156;
            ViewBag.Prestados = 43;
            ViewBag.Mantenimiento = 12;

            return View();
        }

        public IActionResult Inventario()
        {
            return View();
        }

        // API endpoints para operaciones de inventario
        [HttpGet]
        public IActionResult GetEquipos()
        {
            var equipos = new List<object>
            {
                new { id = 1, codigo = "IT-001", nombre = "Laptop HP EliteBook 840", categoria = "Laptop", marca = "HP", modelo = "EliteBook 840 G9", serie = "CNU1234567", estado = "disponible", ubicacion = "Recepción", usuario = "Admin", notas = "" },
                new { id = 2, codigo = "IT-002", nombre = "Monitor Dell UltraSharp 27\"", categoria = "Monitor", marca = "Dell", modelo = "U2722D", serie = "DELL987654", estado = "prestado", ubicacion = "Gerencia", usuario = "Juan Pérez", notas = "" },
                new { id = 3, codigo = "IT-003", nombre = "Switch TP-Link 24 puertos", categoria = "Red", marca = "TP-Link", modelo = "TL-SG1024", serie = "TPLK112233", estado = "mantenimiento", ubicacion = "Cuarto de redes", usuario = "Admin", notas = "Revisión de puertos" },
                new { id = 4, codigo = "IT-004", nombre = "UPS APC Smart-UPS 1500", categoria = "UPS / Energía", marca = "APC", modelo = "SMT1500", serie = "APC4445566", estado = "disponible", ubicacion = "Almacén TI", usuario = "Admin", notas = "" },
                new { id = 5, codigo = "IT-005", nombre = "Laptop Lenovo ThinkPad E14", categoria = "Laptop", marca = "Lenovo", modelo = "ThinkPad E14 G3", serie = "LNV7788990", estado = "baja", ubicacion = "Almacén TI", usuario = "Admin", notas = "Pantalla dañada" }
            };

            return Json(equipos);
        }

        [HttpPost]
        public IActionResult GuardarEquipo([FromBody] EquipoModel equipo)
        {
            // Aquí iría la lógica para guardar en la base de datos
            return Json(new { success = true, message = "Equipo guardado correctamente" });
        }

        [HttpDelete]
        public IActionResult EliminarEquipo(int id)
        {
            // Aquí iría la lógica para eliminar de la base de datos
            return Json(new { success = true, message = "Equipo eliminado correctamente" });
        }

        public IActionResult Entradas()
        {
            return View();
        }

        public IActionResult Prestamos()
        {
            return View();
        }

        public IActionResult Facturas()
        {
            return View();
        }

        public IActionResult Usuarios()
        {
            return View();
        }

        public IActionResult Historial()
        {
            return View();
        }

        public IActionResult Reportes()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}