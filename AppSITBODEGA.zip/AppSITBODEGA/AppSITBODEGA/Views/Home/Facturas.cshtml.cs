using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppSITBODEGA.Views.Home
{
    public class FacturasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
