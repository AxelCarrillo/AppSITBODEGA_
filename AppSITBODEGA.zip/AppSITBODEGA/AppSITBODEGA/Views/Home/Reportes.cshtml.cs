using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppSITBODEGA.Views.Home
{
    public class ReportesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
