using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppSITBODEGA.Views.Home
{
    public class UsuariosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
