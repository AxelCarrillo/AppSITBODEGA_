using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppSITBODEGA.Views.Account
{
    public class ForgotPasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
