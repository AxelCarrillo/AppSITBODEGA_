using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppSITBODEGA.Views.Shared
{
    public class _DashboardLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
